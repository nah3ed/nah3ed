# bitcoinFinder
This created for only test and to study

Checking all bitcoin address and if balance is not zero saving in file bitcoin address and private key
